/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/_app";
exports.ids = ["pages/_app"];
exports.modules = {

/***/ "./pages/_app.tsx":
/*!************************!*\
  !*** ./pages/_app.tsx ***!
  \************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ App)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _App_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./App.css */ \"./pages/App.css\");\n/* harmony import */ var _App_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_App_css__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var _App_scss__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./App.scss */ \"./pages/App.scss\");\n/* harmony import */ var _App_scss__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_App_scss__WEBPACK_IMPORTED_MODULE_3__);\n/* harmony import */ var openai__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! openai */ \"openai\");\n/* harmony import */ var openai__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(openai__WEBPACK_IMPORTED_MODULE_4__);\n/* harmony import */ var next_config__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! next/config */ \"next/config\");\n/* harmony import */ var next_config__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_config__WEBPACK_IMPORTED_MODULE_5__);\n\n\n\n\n\n\nfunction App({ Component , pageProps  }) {\n    const [result, setResult] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(\"https://cdn.pixabay.com/photo/2016/08/08/09/17/avatar-1577909_960_720.png\");\n    const [prompt, setPrompt] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(\"\");\n    const [loading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);\n    const [typedText, setTypedText] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(\"\");\n    const text = \"Creating image...Please Wait...\";\n    const stars = [];\n    for(let i = 0; i < 20; i++){\n        stars.push(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n            className: \"shooting_star\"\n        }, i, false, {\n            fileName: \"/Users/clarian/Desktop/image-gen-app/image-gen-project/pages/_app.tsx\",\n            lineNumber: 18,\n            columnNumber: 16\n        }, this));\n    }\n    const { publicRuntimeConfig  } = next_config__WEBPACK_IMPORTED_MODULE_5___default()();\n    const apiKey = typeof publicRuntimeConfig !== \"undefined\" && publicRuntimeConfig.apiKey ? publicRuntimeConfig.apiKey : process.env.API_KEY;\n    if (!apiKey) {\n        throw new Error(\"apiKey is not defined in config file\");\n    }\n    const configuration = new openai__WEBPACK_IMPORTED_MODULE_4__.Configuration({\n        apiKey\n    });\n    const openai = new openai__WEBPACK_IMPORTED_MODULE_4__.OpenAIApi(configuration);\n    const generateImage = async ()=>{\n        setLoading(true);\n        const res = await openai.createImage({\n            prompt: prompt,\n            n: 1,\n            size: \"512x512\"\n        });\n        setLoading(false);\n        const data = res.data;\n        console.log(data);\n        setResult(data.data[0].url || \"no image found\");\n    };\n    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{\n        if (loading) {\n            let i = 0;\n            const typing = setInterval(()=>{\n                setTypedText(text.slice(0, i));\n                i++;\n                if (i > text.length + 1) {\n                    i = 0;\n                    setTypedText(\"\");\n                }\n            }, 100);\n            return ()=>clearInterval(typing);\n        }\n    // write some logic here\n    }, [\n        loading\n    ]);\n    const sendEmail = (url = \"\")=>{\n        url = result;\n        const message = `Here's your image download link: ${url}`;\n        window.location.href = `mailto:someone@example.com?subject=Image Download Link&body=${message}`;\n    };\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        className: \"app-main\",\n        children: [\n            stars,\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"h2\", {\n                children: \"Create Images With Your Imagination\"\n            }, void 0, false, {\n                fileName: \"/Users/clarian/Desktop/image-gen-app/image-gen-project/pages/_app.tsx\",\n                lineNumber: 69,\n                columnNumber: 5\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"textarea\", {\n                className: \"app-input\",\n                placeholder: \"Create any type of image you can think of with as much added description as you would like\",\n                onChange: (e)=>setPrompt(e.target.value)\n            }, void 0, false, {\n                fileName: \"/Users/clarian/Desktop/image-gen-app/image-gen-project/pages/_app.tsx\",\n                lineNumber: 70,\n                columnNumber: 5\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"button\", {\n                onClick: generateImage,\n                children: \"Generate Image\"\n            }, void 0, false, {\n                fileName: \"/Users/clarian/Desktop/image-gen-app/image-gen-project/pages/_app.tsx\",\n                lineNumber: 76,\n                columnNumber: 5\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {\n                children: loading ? /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {\n                    children: [\n                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"h3\", {\n                            children: typedText\n                        }, void 0, false, {\n                            fileName: \"/Users/clarian/Desktop/image-gen-app/image-gen-project/pages/_app.tsx\",\n                            lineNumber: 79,\n                            columnNumber: 5\n                        }, this),\n                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                            className: \"lds-ripple\",\n                            children: [\n                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {}, void 0, false, {\n                                    fileName: \"/Users/clarian/Desktop/image-gen-app/image-gen-project/pages/_app.tsx\",\n                                    lineNumber: 81,\n                                    columnNumber: 7\n                                }, this),\n                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {}, void 0, false, {\n                                    fileName: \"/Users/clarian/Desktop/image-gen-app/image-gen-project/pages/_app.tsx\",\n                                    lineNumber: 82,\n                                    columnNumber: 7\n                                }, this)\n                            ]\n                        }, void 0, true, {\n                            fileName: \"/Users/clarian/Desktop/image-gen-app/image-gen-project/pages/_app.tsx\",\n                            lineNumber: 80,\n                            columnNumber: 5\n                        }, this)\n                    ]\n                }, void 0, true) : /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"img\", {\n                    src: result,\n                    onClick: ()=>sendEmail(result),\n                    style: {\n                        cursor: \"pointer\"\n                    },\n                    className: \"result-image\",\n                    alt: \"result\"\n                }, void 0, false, {\n                    fileName: \"/Users/clarian/Desktop/image-gen-app/image-gen-project/pages/_app.tsx\",\n                    lineNumber: 86,\n                    columnNumber: 7\n                }, this)\n            }, void 0, false)\n        ]\n    }, void 0, true, {\n        fileName: \"/Users/clarian/Desktop/image-gen-app/image-gen-project/pages/_app.tsx\",\n        lineNumber: 67,\n        columnNumber: 10\n    }, this);\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9fYXBwLnRzeC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUMwQztBQUN2QjtBQUNDO0FBQzhCO0FBQ2Q7QUFFckIsU0FBU0ssSUFBSSxFQUFFQyxVQUFTLEVBQUVDLFVBQVMsRUFBWSxFQUFFO0lBRTlELE1BQU0sQ0FBQ0MsUUFBUUMsVUFBVSxHQUFHVCwrQ0FBUUEsQ0FBQztJQUNyQyxNQUFNLENBQUNVLFFBQVFDLFVBQVUsR0FBR1gsK0NBQVFBLENBQUM7SUFDckMsTUFBTSxDQUFDWSxTQUFTQyxXQUFXLEdBQUdiLCtDQUFRQSxDQUFDLEtBQUs7SUFDNUMsTUFBTSxDQUFDYyxXQUFXQyxhQUFhLEdBQUdmLCtDQUFRQSxDQUFDO0lBQzNDLE1BQU1nQixPQUFPO0lBRWIsTUFBTUMsUUFBUSxFQUFFO0lBQ2hCLElBQUksSUFBSUMsSUFBSSxHQUFHQSxJQUFJLElBQUlBLElBQUs7UUFDMUJELE1BQU1FLElBQUksZUFBQyw4REFBQ0M7WUFBSUMsV0FBVTtXQUFxQkg7Ozs7O0lBQ2pEO0lBRUEsTUFBTSxFQUFFSSxvQkFBbUIsRUFBRSxHQUFHbEIsa0RBQVNBO0lBQ3pDLE1BQU1tQixTQUFTLE9BQVFELHdCQUF3QixlQUFlQSxvQkFBb0JDLE1BQU0sR0FBSUQsb0JBQW9CQyxNQUFNLEdBQUdDLFFBQVFDLEdBQUcsQ0FBQ0MsT0FBTztJQUM1SSxJQUFJLENBQUNILFFBQVE7UUFDWCxNQUFNLElBQUlJLE1BQU0sd0NBQXVDO0lBQ3pELENBQUM7SUFFRCxNQUFNQyxnQkFBZ0IsSUFBSTFCLGlEQUFhQSxDQUFDO1FBQUNxQjtJQUFNO0lBQy9DLE1BQU1NLFNBQVMsSUFBSTFCLDZDQUFTQSxDQUFDeUI7SUFFN0IsTUFBTUUsZ0JBQWdCLFVBQVk7UUFDaENqQixXQUFXLElBQUk7UUFDZixNQUFNa0IsTUFBTSxNQUFNRixPQUFPRyxXQUFXLENBQUM7WUFDbkN0QixRQUFPQTtZQUNQdUIsR0FBRTtZQUNGQyxNQUFLO1FBQ1Q7UUFDRXJCLFdBQVcsS0FBSztRQUNoQixNQUFNc0IsT0FBT0osSUFBSUksSUFBSTtRQUNyQkMsUUFBUUMsR0FBRyxDQUFDRjtRQUNiMUIsVUFBVTBCLEtBQUtBLElBQUksQ0FBQyxFQUFFLENBQUNHLEdBQUcsSUFBSTtJQUMvQjtJQUVBckMsZ0RBQVNBLENBQUMsSUFBTTtRQUVkLElBQUdXLFNBQVM7WUFDVixJQUFJTSxJQUFJO1lBQ1IsTUFBTXFCLFNBQVNDLFlBQVksSUFBSztnQkFDOUJ6QixhQUFhQyxLQUFLeUIsS0FBSyxDQUFDLEdBQUV2QjtnQkFDMUJBO2dCQUNBLElBQUlBLElBQUlGLEtBQUswQixNQUFNLEdBQUcsR0FBRztvQkFDdkJ4QixJQUFJO29CQUNKSCxhQUFhO2dCQUNmLENBQUM7WUFDSCxHQUFFO1lBQ0YsT0FBTyxJQUFNNEIsY0FBY0o7UUFDN0IsQ0FBQztJQUNELHdCQUF3QjtJQUUxQixHQUFHO1FBQUMzQjtLQUFRO0lBRVosTUFBTWdDLFlBQVksQ0FBQ04sTUFBTSxFQUFFLEdBQUs7UUFDOUJBLE1BQU05QjtRQUNOLE1BQU1xQyxVQUFVLENBQUMsaUNBQWlDLEVBQUVQLElBQUksQ0FBQztRQUN6RFEsT0FBT0MsUUFBUSxDQUFDQyxJQUFJLEdBQUcsQ0FBQyw0REFBNEQsRUFBRUgsUUFBUSxDQUFDO0lBQ2pHO0lBRUEscUJBQU8sOERBQUN6QjtRQUFJQyxXQUFVOztZQUNuQko7MEJBQ0QsOERBQUNnQzswQkFBRzs7Ozs7OzBCQUNKLDhEQUFDQztnQkFDQzdCLFdBQVU7Z0JBQ1Y4QixhQUFZO2dCQUVaQyxVQUFVLENBQUNDLElBQUsxQyxVQUFVMEMsRUFBRUMsTUFBTSxDQUFDQyxLQUFLOzs7Ozs7MEJBRTFDLDhEQUFDQztnQkFBT0MsU0FBUzNCOzBCQUFlOzs7Ozs7MEJBQ2hDOzBCQUFHbEIsd0JBQ0g7O3NDQUNBLDhEQUFDOEM7c0NBQUk1Qzs7Ozs7O3NDQUNMLDhEQUFDTTs0QkFBSUMsV0FBVTs7OENBQ2IsOERBQUNEOzs7Ozs4Q0FDRCw4REFBQ0E7Ozs7Ozs7Ozs7OztpREFJRCw4REFBQ3VDO29CQUFJQyxLQUFLcEQ7b0JBQVFpRCxTQUFTLElBQUtiLFVBQVVwQztvQkFBU3FELE9BQU87d0JBQUNDLFFBQVE7b0JBQVM7b0JBQUd6QyxXQUFVO29CQUFlMEMsS0FBSTs7Ozs7d0JBQVc7Ozs7Ozs7O0FBSTdILENBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9pbWFnZS1nZW4tcHJvamVjdC8uL3BhZ2VzL19hcHAudHN4PzJmYmUiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHR5cGUgeyBBcHBQcm9wcyB9IGZyb20gJ25leHQvYXBwJztcbmltcG9ydCB7dXNlU3RhdGUsIHVzZUVmZmVjdH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IFwiLi9BcHAuY3NzXCI7XG5pbXBvcnQgXCIuL0FwcC5zY3NzXCI7XG5pbXBvcnQgeyBDb25maWd1cmF0aW9uLCBPcGVuQUlBcGkgfSBmcm9tICdvcGVuYWknO1xuaW1wb3J0IGdldENvbmZpZyBmcm9tICduZXh0L2NvbmZpZyc7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEFwcCh7IENvbXBvbmVudCwgcGFnZVByb3BzIH06IEFwcFByb3BzKSB7XG5cbiAgY29uc3QgW3Jlc3VsdCwgc2V0UmVzdWx0XSA9IHVzZVN0YXRlKFwiaHR0cHM6Ly9jZG4ucGl4YWJheS5jb20vcGhvdG8vMjAxNi8wOC8wOC8wOS8xNy9hdmF0YXItMTU3NzkwOV85NjBfNzIwLnBuZ1wiKTtcbiAgY29uc3QgW3Byb21wdCwgc2V0UHJvbXB0XSA9IHVzZVN0YXRlKFwiXCIpO1xuICBjb25zdCBbbG9hZGluZywgc2V0TG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFt0eXBlZFRleHQsIHNldFR5cGVkVGV4dF0gPSB1c2VTdGF0ZShcIlwiKTtcbiAgY29uc3QgdGV4dCA9IFwiQ3JlYXRpbmcgaW1hZ2UuLi5QbGVhc2UgV2FpdC4uLlwiO1xuXG4gIGNvbnN0IHN0YXJzID0gW107XG4gIGZvcihsZXQgaSA9IDA7IGkgPCAyMDsgaSsrKSB7XG4gICAgc3RhcnMucHVzaCg8ZGl2IGNsYXNzTmFtZT1cInNob290aW5nX3N0YXJcIiBrZXk9e2l9PjwvZGl2PilcbiAgfVxuXG4gIGNvbnN0IHsgcHVibGljUnVudGltZUNvbmZpZyB9ID0gZ2V0Q29uZmlnKCk7XG4gIGNvbnN0IGFwaUtleSA9ICh0eXBlb2YgcHVibGljUnVudGltZUNvbmZpZyAhPT0gJ3VuZGVmaW5lZCcgJiYgcHVibGljUnVudGltZUNvbmZpZy5hcGlLZXkpID8gcHVibGljUnVudGltZUNvbmZpZy5hcGlLZXkgOiBwcm9jZXNzLmVudi5BUElfS0VZO1xuICBpZiAoIWFwaUtleSkge1xuICAgIHRocm93IG5ldyBFcnJvcignYXBpS2V5IGlzIG5vdCBkZWZpbmVkIGluIGNvbmZpZyBmaWxlJylcbiAgfVxuIFxuICBjb25zdCBjb25maWd1cmF0aW9uID0gbmV3IENvbmZpZ3VyYXRpb24oe2FwaUtleX0pO1xuICBjb25zdCBvcGVuYWkgPSBuZXcgT3BlbkFJQXBpKGNvbmZpZ3VyYXRpb24pO1xuICBcbiAgY29uc3QgZ2VuZXJhdGVJbWFnZSA9IGFzeW5jICgpID0+IHtcbiAgICBzZXRMb2FkaW5nKHRydWUpO1xuICAgIGNvbnN0IHJlcyA9IGF3YWl0IG9wZW5haS5jcmVhdGVJbWFnZSh7XG4gICAgICBwcm9tcHQ6cHJvbXB0LFxuICAgICAgbjoxLFxuICAgICAgc2l6ZTpcIjUxMng1MTJcIlxuICB9KVxuICAgIHNldExvYWRpbmcoZmFsc2UpO1xuICAgIGNvbnN0IGRhdGEgPSByZXMuZGF0YTtcbiAgICBjb25zb2xlLmxvZyhkYXRhKTtcbiAgIHNldFJlc3VsdChkYXRhLmRhdGFbMF0udXJsIHx8ICdubyBpbWFnZSBmb3VuZCcpO1xuICB9XG4gIFxuICB1c2VFZmZlY3QoKCkgPT4ge1xuXG4gICAgaWYobG9hZGluZykge1xuICAgICAgbGV0IGkgPSAwO1xuICAgICAgY29uc3QgdHlwaW5nID0gc2V0SW50ZXJ2YWwoKCk9PiB7XG4gICAgICAgIHNldFR5cGVkVGV4dCh0ZXh0LnNsaWNlKDAsaSkpO1xuICAgICAgICBpKys7XG4gICAgICAgIGlmKCBpID4gdGV4dC5sZW5ndGggKyAxKSB7XG4gICAgICAgICAgaSA9IDA7XG4gICAgICAgICAgc2V0VHlwZWRUZXh0KCcnKTtcbiAgICAgICAgfVxuICAgICAgfSwxMDApO1xuICAgICAgcmV0dXJuICgpID0+IGNsZWFySW50ZXJ2YWwodHlwaW5nKVxuICAgIH1cbiAgICAvLyB3cml0ZSBzb21lIGxvZ2ljIGhlcmVcblxuICB9LCBbbG9hZGluZ10pXG5cbiAgY29uc3Qgc2VuZEVtYWlsID0gKHVybCA9IFwiXCIpID0+IHtcbiAgICB1cmwgPSByZXN1bHQ7XG4gICAgY29uc3QgbWVzc2FnZSA9IGBIZXJlJ3MgeW91ciBpbWFnZSBkb3dubG9hZCBsaW5rOiAke3VybH1gO1xuICAgIHdpbmRvdy5sb2NhdGlvbi5ocmVmID0gYG1haWx0bzpzb21lb25lQGV4YW1wbGUuY29tP3N1YmplY3Q9SW1hZ2UgRG93bmxvYWQgTGluayZib2R5PSR7bWVzc2FnZX1gO1xuICB9XG5cbiAgcmV0dXJuIDxkaXYgY2xhc3NOYW1lPVwiYXBwLW1haW5cIj5cbiAgICB7c3RhcnN9XG4gICAgPGgyPkNyZWF0ZSBJbWFnZXMgV2l0aCBZb3VyIEltYWdpbmF0aW9uPC9oMj5cbiAgICA8dGV4dGFyZWFcbiAgICAgIGNsYXNzTmFtZT1cImFwcC1pbnB1dFwiXG4gICAgICBwbGFjZWhvbGRlcj1cIkNyZWF0ZSBhbnkgdHlwZSBvZiBpbWFnZSB5b3UgY2FuIHRoaW5rIG9mIHdpdGggXG4gIGFzIG11Y2ggYWRkZWQgZGVzY3JpcHRpb24gYXMgeW91IHdvdWxkIGxpa2VcIlxuICAgICAgb25DaGFuZ2U9eyhlKT0+IHNldFByb21wdChlLnRhcmdldC52YWx1ZSl9XG4gICAgLz5cbiAgICA8YnV0dG9uIG9uQ2xpY2s9e2dlbmVyYXRlSW1hZ2V9PkdlbmVyYXRlIEltYWdlPC9idXR0b24+XG4gICAgPD57bG9hZGluZyA/IChcbiAgICA8PlxuICAgIDxoMz57dHlwZWRUZXh0fTwvaDM+XG4gICAgPGRpdiBjbGFzc05hbWU9J2xkcy1yaXBwbGUnPlxuICAgICAgPGRpdj48L2Rpdj5cbiAgICAgIDxkaXY+PC9kaXY+XG4gICAgPC9kaXY+XG4gICAgPC8+XG4gICAgKSA6IFxuICAgICAgPGltZyBzcmM9e3Jlc3VsdH0gb25DbGljaz17KCk9PiBzZW5kRW1haWwocmVzdWx0KX0gc3R5bGU9e3tjdXJzb3I6IFwicG9pbnRlclwifX0gY2xhc3NOYW1lPVwicmVzdWx0LWltYWdlXCIgYWx0PVwicmVzdWx0XCIgLz5cbiAgICB9XG4gICAgPC8+XG4gIDwvZGl2PlxufVxuIl0sIm5hbWVzIjpbInVzZVN0YXRlIiwidXNlRWZmZWN0IiwiQ29uZmlndXJhdGlvbiIsIk9wZW5BSUFwaSIsImdldENvbmZpZyIsIkFwcCIsIkNvbXBvbmVudCIsInBhZ2VQcm9wcyIsInJlc3VsdCIsInNldFJlc3VsdCIsInByb21wdCIsInNldFByb21wdCIsImxvYWRpbmciLCJzZXRMb2FkaW5nIiwidHlwZWRUZXh0Iiwic2V0VHlwZWRUZXh0IiwidGV4dCIsInN0YXJzIiwiaSIsInB1c2giLCJkaXYiLCJjbGFzc05hbWUiLCJwdWJsaWNSdW50aW1lQ29uZmlnIiwiYXBpS2V5IiwicHJvY2VzcyIsImVudiIsIkFQSV9LRVkiLCJFcnJvciIsImNvbmZpZ3VyYXRpb24iLCJvcGVuYWkiLCJnZW5lcmF0ZUltYWdlIiwicmVzIiwiY3JlYXRlSW1hZ2UiLCJuIiwic2l6ZSIsImRhdGEiLCJjb25zb2xlIiwibG9nIiwidXJsIiwidHlwaW5nIiwic2V0SW50ZXJ2YWwiLCJzbGljZSIsImxlbmd0aCIsImNsZWFySW50ZXJ2YWwiLCJzZW5kRW1haWwiLCJtZXNzYWdlIiwid2luZG93IiwibG9jYXRpb24iLCJocmVmIiwiaDIiLCJ0ZXh0YXJlYSIsInBsYWNlaG9sZGVyIiwib25DaGFuZ2UiLCJlIiwidGFyZ2V0IiwidmFsdWUiLCJidXR0b24iLCJvbkNsaWNrIiwiaDMiLCJpbWciLCJzcmMiLCJzdHlsZSIsImN1cnNvciIsImFsdCJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./pages/_app.tsx\n");

/***/ }),

/***/ "./pages/App.css":
/*!***********************!*\
  !*** ./pages/App.css ***!
  \***********************/
/***/ (() => {



/***/ }),

/***/ "./pages/App.scss":
/*!************************!*\
  !*** ./pages/App.scss ***!
  \************************/
/***/ (() => {



/***/ }),

/***/ "next/config":
/*!******************************!*\
  !*** external "next/config" ***!
  \******************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/config");

/***/ }),

/***/ "openai":
/*!*************************!*\
  !*** external "openai" ***!
  \*************************/
/***/ ((module) => {

"use strict";
module.exports = require("openai");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/_app.tsx"));
module.exports = __webpack_exports__;

})();